import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PathPages {

	private String url;
	private String heading;
	Browser browser=new Browser();
	public PathPages(String url,String heading) {
		String webPageLocation="file:///"+System.getProperty("user.dir")+"\\src\\main\\webapp\\";
		
		this.url=webPageLocation+url;
		this.heading=heading;
	}
	
	public void goTo() {
		browser.goTo(url);
	}
	@FindBy(xpath="//*[@id='mainCnt']/div/div[1]/h1")
	WebElement WebHeading;
	public boolean isAt() {
		return WebHeading.getText().equals(heading);
	}

	public Browser getBrowser() {
		return browser;
	}
	
}
