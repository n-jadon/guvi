import org.junit.Assert;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefForConferenceRegistration {
	private ConferenceRegistration page=new ConferenceRegistration();
	@Given("^I am on the ConferenceRegistration\\.html page$")
	public void i_am_on_the_ConferenceRegistration_html_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	page.goTo();
	}

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		Assert.assertTrue(page.isAt());
	}

	@When("^I leave the first name blank$")
	public void i_leave_the_first_name_blank(String firstName) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
	}

	@When("^I click on the Next button$")
	public void i_click_on_the_Next_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
	}

	@Then("^display Please fill the First Name alert$")
	public void display_Please_fill_the_First_Name_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		Assert.assertTrue(page.invalidFirstName());
	}

	@When("^I leave the last name blank$")
	public void i_leave_the_last_name_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
	}

	@Then("^display Please fill the Last Name alert$")
	public void display_Please_fill_the_Last_Name_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		Assert.assertTrue(page.invalidLastName());
	}

	@When("^I leave the email blank$")
	public void i_leave_the_email_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display Please fill the email alert$")
	public void display_Please_fill_the_email_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I enter all the data$")
	public void i_enter_all_the_data() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I enter incorrect email format$")
	public void i_enter_incorrect_email_format() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display wrong email format alert$")
	public void display_wrong_email_format_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave the Mobile number blank$")
	public void i_leave_the_Mobile_number_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display mobile number not entered alert$")
	public void display_mobile_number_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I enter incorrect mobile number format$")
	public void i_enter_incorrect_mobile_number_format() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I click on the Next button$")
	public void i_click_on_the_Next_button(DataTable arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    throw new PendingException();
	}

	@Then("^display wrong mobile number format alert$")
	public void display_wrong_mobile_number_format_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave the People Attending blank$")
	public void i_leave_the_People_Attending_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display People Attending not entered alert$")
	public void display_People_Attending_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave the BuildingName and RoomNo blank$")
	public void i_leave_the_BuildingName_and_RoomNo_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display BuildingName and roomNo not entered alert$")
	public void display_BuildingName_and_roomNo_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave AreaName blank$")
	public void i_leave_AreaName_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display AreaName not entered alert$")
	public void display_AreaName_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave City blank$")
	public void i_leave_City_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display City not entered alert$")
	public void display_City_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave state blank$")
	public void i_leave_state_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display state not entered alert$")
	public void display_state_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave status blank$")
	public void i_leave_status_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display status not entered alert$")
	public void display_status_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I am on  the ConferenceRegistration\\.html page$")
	public void i_am_on_the_ConferenceRegistration_html_page1() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I enter all valid Registration data$")
	public void i_enter_all_valid_Registration_data() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^navigate to PaymentDetails\\.html page$")
	public void navigate_to_PaymentDetails_html_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I am on the PaymentDetails\\.html page$")
	public void i_am_on_the_PaymentDetails_html_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^verify the title of the Payment page$")
	public void verify_the_title_of_the_Payment_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave CardHolderName blank and click the button$")
	public void i_leave_CardHolderName_blank_and_click_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display CardHolderName not entered alert$")
	public void display_CardHolderName_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave DebitCardNo blank and click the button$")
	public void i_leave_DebitCardNo_blank_and_click_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display DebitCardNo not entered alert$")
	public void display_DebitCardNo_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^User is on PaymentDetails\\.html page$")
	public void user_is_on_PaymentDetails_html_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display expirationMonth alert msg$")
	public void display_expirationMonth_alert_msg() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I leave expirationYr blank and click the button$")
	public void i_leave_expirationYr_blank_and_click_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display expirationYr not entered alert$")
	public void display_expirationYr_not_entered_alert() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I enter all valid Payment details and click the button$")
	public void i_enter_all_valid_Payment_details_and_click_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^check the alert message$")
	public void check_the_alert_message() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I want to write a step with name(\\d+)$")
	public void i_want_to_write_a_step_with_name(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I check for the (\\d+) in step$")
	public void i_check_for_the_in_step(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I verify the success in step$")
	public void i_verify_the_success_in_step() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I verify the Fail in step$")
	public void i_verify_the_Fail_in_step() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}



}
