import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ConferenceRegistration extends PathPages {
	private static String page="ConferenceRegistration.html";
	private static String title = "Conference Registration";

	public ConferenceRegistration() {
		super(page, title);
		PageFactory.initElements(Browser.driver, this);
	}
	@FindBy(how=How.ID,id="txtFirstName")
	private WebElement firstName;
	
	@FindBy(how=How.ID,id="txtLastName")
	private WebElement lastName;
	
	@FindBy(how=How.ID,id="txtEmail")
	private WebElement email;
	
	@FindBy(how=How.ID,id="txtPhone")
	private WebElement mobileNo;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td")
	private WebElement address;
	
	@FindBy(how=How.NAME,name="city")
	private WebElement city;
	
	@FindBy(how=How.NAME,name="state")
	private WebElement state;
	
	@FindBy(how=How.NAME,name="persons")
	private WebElement persons;
	/////////////////////////////////////////////////
	
	@FindBy(how=How.ID,id="txtCardholderName")
	private WebElement cardHolderName;
	
	@FindBy(how=How.ID,id="txtDebit")
	private WebElement debitCardNumber;
	
	@FindBy(how=How.ID,id="txtCvv")
	private WebElement cvv;
	
	@FindBy(how=How.ID,id="txtMonth")
	private WebElement expMonth;

	@FindBy(how=How.ID,id="txtYear")
	private WebElement expYear;
	
	@FindBy(how=How.ID,id="btnPayment")
	private WebElement btn;

	public String getFirstName() {
		return firstName.getText();
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getText();
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getText();
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getMobileNo() {
		return mobileNo.getText();
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public String getAddress() {
		return address.getText();
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCity() {
		return city.getText();
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getState() {
		return state.getText();
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public String getPersons() {
		return persons.getText();
	}

	public void setPersons(String persons) {
		this.persons.sendKeys(persons);
	}
	@FindBy(how=How.ID,id="userErrMsg")
	private WebElement userErrMsg;
	public boolean invalidFirstName() {
		System.out.println("\n"+userErrMsg.getText());
		if((userErrMsg.getText()).equals("* Please enter firstName."))
			return true;
		return false;
	}
	@FindBy(how=How.ID,id="userErrMsg")
	private WebElement userErrMsg1;
	public boolean invalidLastName() {
		// TODO Auto-generated method stub
		System.out.println("\n"+userErrMsg1.getText());
		if((userErrMsg1.getText()).equals("* Please enter lastName."))
			return true;
		return false;
	}
	@FindBy(how=How.ID,id="userErrMsg")
	private WebElement userErrMsg2;
	public boolean invalidEmail() {
		// TODO Auto-generated method stub
		System.out.println("\n"+userErrMsg2.getText());
		if((userErrMsg2.getText()).equals("* Please enter email."))
			return true;
		return false;
	}


//////////////////////////////////////////////////////
	public String getCardHolderName() {
		return cardHolderName.getText();
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public String getDebitCardNumber() {
		return debitCardNumber.getText();
	}

	public void setDebitCardNumber(String debitCardNumber) {
		this.debitCardNumber.sendKeys(debitCardNumber);
	}

	public String getCvv() {
		return cvv.getText();
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public String getExpMonth() {
		return expMonth.getText();
	}

	public void setExpMonth(String expMonth) {
		this.expMonth.sendKeys(expMonth);
	}

	public String getExpYear() {
		return expYear.getText();
	}

	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear);
	}
	public WebElement getBtn() {
		return btn;
	}
}

	